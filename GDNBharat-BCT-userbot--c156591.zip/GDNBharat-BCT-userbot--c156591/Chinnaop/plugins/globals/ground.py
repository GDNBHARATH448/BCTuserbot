# Powered By // @aboutchinnalu //

__NAME__ = "Gʟᴏʙᴀʟ"
__MENU__ = """
**Reply On Target Users Messages
To Globally Tapped.**

`.gdl` - Delete User Messages.
`.ugdl` - Stop Message Delete.

`.gbn` - Ban An User Globally.
`.ugbn` - Remove Global Ban.

`.gmt` - Mute An User Gkobally.
`.ugmt` - Remove Global Mute.

**Some More Commands:**
Global Delete: .gdel | .ungdel
Global Ban: .gban | .ungban
Global Mute: .gmute | .ungmute
"""
