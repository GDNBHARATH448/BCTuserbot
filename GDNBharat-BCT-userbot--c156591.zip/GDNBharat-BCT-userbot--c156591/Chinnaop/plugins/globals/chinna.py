# Powered By // @aboutchinnalu //

__NAME__ = "Sʜᴜᴋʟᴀ"
__MENU__ = """
 **@aboutchinnalu**
"""
