#      chinna 𝗨𝗦𝗘𝗥𝗕𝗢𝗧

<p align="center"> 𝗔 𝗣𝗢𝗪𝗘𝗥𝗙𝗨𝗟 𝗜𝗗 𝗨𝗦𝗘𝗥𝗕𝗢𝗧 </p>

<p align="center"><a href="https://t.me/Reddragon_op"><img src="https://graph.org/file/4c5a86c94afb9f7cd04ac5079f73c98699c4f86.jpg" width="400"></a></p>
</p>
<h6 align="center">
  <b>• sᴛʀᴀɴɢᴇʀ ᴜsᴇʀ ʙᴏᴛ •</b>
</h6>

----

<h2> Heroku Deployment </h2>

> The easy way to host this bot, deploy to Heroku 
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/GDNBharat/BCT-userbot-)

## 🖇 Generating Pyrogram String Session

<p>
<a href="https://t.me/aboutchinnalu"><img src="https://img.shields.io/badge/TG%20String%20Gen%20Bot-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a>

### Contact :
<a href="https://t.me/Reddragon_op"><img title="Telegram" src="https://img.shields.io/badge/Telegram-%23000000.svg?&style=for-the-badge&logo=telegram&logoColor=61DAFB"></a>



<p align="center">
<a href="https://t.me/aboutchinnalu"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

